package com.example.shea.goldenpoint2rd;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    private int round;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        final Button start = (Button) findViewById(R.id.start);
        Button delete = (Button) findViewById(R.id.delete);
        Button history = (Button) findViewById(R.id.history);
        Button rules = (Button) findViewById(R.id.rules);
        SharedPreferences tempData = getSharedPreferences("tempData", MODE_APPEND);
        final SharedPreferences.Editor dataEdit = tempData.edit();
        round=tempData.getInt("round",1);


        assert start != null;
        start.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(MainActivity.this,gameInterface.class);
                startActivity(intent);

            }
        });

        assert delete != null;
        delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dataEdit.clear();
                if (round!=0){
                    for (int i = 1; i <=round ; i++) {
                        dataEdit.remove(Integer.toString(i));
                        dataEdit.commit();
                    }
                }
                dataEdit.putInt("round",1);
                Toast.makeText(MainActivity.this,"删除成功！",Toast.LENGTH_SHORT).show();


            }
        });

        assert rules != null;
        rules.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new AlertDialog.Builder(MainActivity.this).
                        setMessage("请输入一个0-100的有理数，然后点击提交，如果需要更改，点击再次提交，如果完成请点击下一位玩家，并将手机传递给下一位玩家，最后一名玩家请点击结束游戏").
                        setTitle("游戏规则").setPositiveButton("懂了！开始游戏！", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        Intent intent=new Intent(MainActivity.this,gameInterface.class);
                        startActivity(intent);

                    }
                }).setNegativeButton("先不游戏   ", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                    }
                }).create().show();

            }
        });

        assert history != null;
        history.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (round==0){
                    Toast.makeText(MainActivity.this,"没有历史数据，快来完一轮吧！~",Toast.LENGTH_LONG).show();
                }
                else
                {
                    Intent intent=new Intent(MainActivity.this,showResult.class);
                    startActivity(intent);
                }

            }
        });


    }
}
