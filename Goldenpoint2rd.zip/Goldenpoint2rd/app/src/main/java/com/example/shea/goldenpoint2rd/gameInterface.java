package com.example.shea.goldenpoint2rd;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class gameInterface extends AppCompatActivity {
    private String username="";
    private double number=0;
    private int ID=1;
    private double G=0;
    private double sum;
    private double distance=0;
    private boolean FLAG=false;
    private String result="";
    private int round=1;
    private information[] userInfo =new information[100];

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gameinterface);
        Button next= (Button) findViewById(R.id.next);
        Button end= (Button) findViewById(R.id.endgame);
        final Button submit= (Button) findViewById(R.id.input_btn);
        final EditText name= (EditText) findViewById(R.id.name);
        final TextView userId= (TextView) findViewById(R.id.userId);
        final TextView showInfo= (TextView) findViewById(R.id.showInfo);
        final EditText inputNum= (EditText) findViewById(R.id.inputNum);
        SharedPreferences tempData=getSharedPreferences("tempData",MODE_APPEND);
        final SharedPreferences.Editor editData=tempData.edit();
        round=tempData.getInt("round",1);
        userId.setText("您是当前第1名玩家");

        assert next != null;//下一个玩家
        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (TextUtils.isEmpty(inputNum.getText().toString())) {
                    Toast.makeText(gameInterface.this, "请输入您的数值!", Toast.LENGTH_SHORT).show();
                } else if (FLAG) {
                    Toast.makeText(gameInterface.this, "请提交数据", Toast.LENGTH_SHORT).show();
                } else {
                    ID++;
                    showInfo.setText("");
                    name.setText("");
                    inputNum.setText("");
                    userId.setText("您是当前第" + ID + "名玩家");
                }

            }
        });



        assert submit != null;
        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (TextUtils.isEmpty(inputNum.getText().toString()))
                    Toast.makeText(gameInterface.this, "请输入数据！", Toast.LENGTH_SHORT).show();
                else if (TextUtils.isEmpty(name.getText().toString()))
                    Toast.makeText(gameInterface.this, "请输入昵称！", Toast.LENGTH_SHORT).show();
                else
                    if (Float.valueOf(inputNum.getText().toString()) < 100 && Float.valueOf(inputNum.getText().toString()) > 0) {
                        InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                        if (imm.isActive() && getCurrentFocus() != null) {
                            if (getCurrentFocus().getWindowToken() != null) {
                                imm.hideSoftInputFromWindow(getCurrentFocus().getWindowToken(), InputMethodManager.HIDE_NOT_ALWAYS);
                            }
                        }
                        number = Double.valueOf(inputNum.getText().toString());
                        username = name.getText().toString();
                        userInfo[ID] = new information(username, number, ID);
                        String test = userInfo[ID].getInfo();
                        System.out.println(test);
                        FLAG = false;
                        showInfo.setText(username + ",您输入的数据是:" + number + '\n' + "您可以输入框内更改输入数据，再点击提交数据");
                        Toast.makeText(gameInterface.this, "提交成功！", Toast.LENGTH_SHORT).show();
                    } else {
                        {Toast.makeText(gameInterface.this, "请输入一个介于0-100之间的有理数", Toast.LENGTH_SHORT).show();
                        inputNum.setText("");
                        }
                    }

            }
        });

        assert end != null;//结束游戏
        end.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (TextUtils.isEmpty(inputNum.getText().toString()))
                    Toast.makeText(gameInterface.this,"请输入数据！",Toast.LENGTH_SHORT).show();
                else if (TextUtils.isEmpty(name.getText().toString()))
                    Toast.makeText(gameInterface.this,"请输入昵称！",Toast.LENGTH_SHORT).show();
                else  if (FLAG){
                    Toast.makeText(gameInterface.this,"请提交数据！",Toast.LENGTH_SHORT).show();
                }else
                if (ID<3)
                {
                    new AlertDialog.Builder(gameInterface.this).setTitle("不符合游戏规则！").setMessage("游戏结束至少需要2人，推荐人数10人").setPositiveButton("退出游戏", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            Intent intent=new Intent(gameInterface.this,MainActivity.class);
                            startActivity(intent);
                        }
                    }).setNegativeButton("继续游戏", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {

                        }
                    }).create().show();
                }
                else{
                    for (int i=1;i<=ID;i++)
                    {
                        sum+= userInfo[i].inputNum;
                    }
                    G=(sum/ID)*0.618;
                    for (int i = 1; i <=ID; i++) {
                        distance= userInfo[i].inputNum -G;
                        userInfo[i].setDistance(distance);
                    }
                    double max= userInfo[1].distance;
                    double min= userInfo[1].distance;
                    for (int i=2;i<=ID;i++)
                    {
                        if (max< userInfo[i].distance)
                            max= userInfo[i].distance;
                        if (min> userInfo[i].distance)
                            min= userInfo[i].distance;
                    }
                    for (int i=1;i<=ID;i++)
                    {
                        if (userInfo[i].distance==max)
                            userInfo[i].setScore(-2);
                        else if (userInfo[i].distance==min)
                            userInfo[i].setScore(ID);
                        else
                            userInfo[i].setScore(0);
                        result=result+'\n'+ userInfo[i].getInfo();

                    }
                    System.out.println(result);
                    String KEY=Integer.toString(round);
                    editData.putString(KEY, result);
                    round++;
                    editData.putInt("round", round);
                    editData.commit();
                    Intent intent=new Intent(gameInterface.this,gameOver.class);
                    intent.putExtra("data",result);
                    startActivity(intent);
                }

            }
        });

    }
}
