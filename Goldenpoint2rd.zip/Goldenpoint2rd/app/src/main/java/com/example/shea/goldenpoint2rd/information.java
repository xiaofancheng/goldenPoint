package com.example.shea.goldenpoint2rd;

public class information {

    public String name="";
    public double inputNum =0;
    public int ID=0;
    public int score=0;
    public double distance=0;
    public void setName(String sname){name=sname;}
    public void setInputnum(double num){
        inputNum =num;}
    public void setID(int id){ID=id;}
    public void setScore(int SCORE){score=SCORE;}
    public void setDistance(double sdistance){distance=sdistance;}

    public information(String sname,double num,int id)
    {
        name=sname;
        inputNum =num;
        ID=id;}

    public String getInfo()
    {
        String info="游戏ID："+ID+"  玩家昵称:"+name+"  分数:"+score+"  输入数据："+ inputNum +'\n';
        return info;}

}
